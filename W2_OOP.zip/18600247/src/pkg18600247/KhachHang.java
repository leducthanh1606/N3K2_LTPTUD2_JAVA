/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg18600247;

import java.util.Scanner;

/**
 *
 * @author Dell 7450
 */
public class KhachHang {

    public void Nhap() {
        Scanner scan = new Scanner(System.in);

        String hsan = "Haisan";
        String bo = "bo";
        String ga = "ga";
        String heo = "heo";
        String chay = "chay";

        System.out.print("Nhập vào tên pizza cần mua:(Haisan, bo, ga, heo,chay): ");
        String tenbanh = scan.nextLine();

        if (tenbanh.equalsIgnoreCase(hsan)) {
            Pizza piza = new PizzaHaiSan();
            piza.NhapThongTinMua(); 
            float a =(float) (piza.TinhTien());
            System.out.print(a);
        } else if (tenbanh.equalsIgnoreCase(bo)) {
            Pizza piza = new PizzaBo();
            piza.NhapThongTinMua();
            float a =(float) (piza.TinhTien());
            System.out.print(a);
        } else if (tenbanh.equalsIgnoreCase(ga)) {
            Pizza piza = new PizzaGa();
            piza.NhapThongTinMua();
            float a =(float) (piza.TinhTien());
            System.out.print(a);
        } else if (tenbanh.equalsIgnoreCase(heo)) {
            Pizza piza = new PizzaHeo();
            piza.NhapThongTinMua();
            float a =(float) (piza.TinhTien());
            System.out.print(a);
        } else if (tenbanh.equalsIgnoreCase(chay)) {
            Pizza piza = new PizzaChay();
            piza.NhapThongTinMua();
            float a =(float) (piza.TinhTien());
            System.out.print(a);
        }    
    }
}

