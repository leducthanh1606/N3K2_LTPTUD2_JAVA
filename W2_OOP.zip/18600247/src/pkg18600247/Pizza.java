/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg18600247;

/**
 *
 * @author Dell 7450
 */

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell 7450
 */
abstract public class Pizza {
    int size;
    int amount;
    
    public int getSize() {
        return size;
    }
    public void setSize(int size) {
        this.size = size;
    }

    public int getAmount() {
        return amount;
    }
    public void setAmount(int amount) {
        this.amount = amount;
    }
    
    
    public  void NhapThongTinMua(){
        Scanner scan = new Scanner(System.in);
        do{
          System.out.print("Nhập size bánh (lớn:Nhập 3, vừa:Nhập 2, nhỏ:Nhập 1): ");
          size = scan.nextInt();
        }while(size != 3 && size != 2 && size != 1 ); 
        System.out.print("Nhập Số Lượng Mua: ");
        amount = scan.nextInt(); 
    };
    
    public abstract float TinhTien();
}

