/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg18600247;
/**
 *
 * @author Dell 7450
 */
public class PizzaChay extends Pizza {


    @Override
    public float TinhTien() {
        //To change body of generated methods, choose Tools | Templates.
        float Tien = 0;
        if (size == 3)
            Tien = (float) (300000 * amount * 0.85);
        else if (size == 2)
            Tien = (float) (200000  * amount * 0.9);
        else if (size == 1 && amount >= 2)
            Tien = (float) (150000 * amount * 0.9);
        else
            Tien = (float) (150000 * amount );
        return Tien;      
    }
   
}
