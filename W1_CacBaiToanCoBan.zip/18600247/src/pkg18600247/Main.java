/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg18600247;

import java.util.Scanner;
import static javafx.beans.binding.Bindings.length;


/**
 *
 * @author Dell 7450
 */

public class Main {
    //Câu 9
    static int SoNghichDao(int n){
        int sodao = 0;
        while(n > 0){
            int temp = n % 10;
            sodao = sodao * 10 + temp;
            n = n/10;
        } 
         return sodao;  
    }
    
    //Câu 11:
    static boolean IsPrime(int n){
        for (int i = 2; i< n; i++){
            if (n % i == 0 ){
                return false;
            }   
        }
        return true;
    }
    static boolean SoThanTai(int n){
        int temp = 0; 
        int demnt = 0; 
        int dem = 0;
        while (n > 0){
            temp = n%10;
            if (IsPrime(temp)== true){
                demnt = demnt +1;
            }
            dem = dem +1;
            n = n/10;
        }
        if(demnt > dem/2){
            return true;
        }
        return false;
    }
    
    //Câu 13:
    static boolean KTLechTrai(int n){
        int tong = 0;
        do{
            int temp = n%10;
            tong = tong + temp;
            n = n/10;
        }while(n > 10);
           
        if (n > tong){
            return true;
        }
        return false;
    }
    
    //Câu 15:  
    static void LoaiTrung(int n){
        int max = 10;             
        int a[] = new int[max];
        int m = 0;
        while (n > 0){
            int temp = n %10;
            a[m] = temp;
            m++;
            n = n/10;            
        }
        int length = a.length;
         for (int i = 0; i < length - 1; i++) {
            for (int j = i + 1; j < length; j++) {
                if (a[i] == a[j]) {
                    int index = j;
                    for (int k = index + 1; k < length; k++) {
                        a[k - 1] = a[k];
                    }
                    length--;
                }
            }
        }

        for (int i = length - 1; i >= 0; i--) {
            if (a[i] == 0) 
                continue;
            System.out.print(a[i]);
        }
    }
    
  
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("Nhập vào n: ");
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        int n = Integer.parseInt(str);
        
        
        System.out.println("Menu chương trình");
        System.out.println("Danh sách chức năng");
        System.out.println("1.Số nghịch đảo");
        System.out.println("2.Số thần tài");
        System.out.println("3.Số lệch trái");
        System.out.println("4.Loại chữ số trùng");
        System.out.println("5.Biến đổi số");
        System.out.println("0.Thoát");
        
        int chon = -1;
        while (chon != 0) {
        System.out.print("Chọn chức năng theo menu: ");
        chon = Integer.parseInt(scan.nextLine());
            switch(chon){
                case 1:
                    // câu 9
                    int SoDao = SoNghichDao(n);
                    String str1 = String.format("Số nghịch đảo cảa %d là %d", n,SoDao);
                    System.out.println(str1);
                    break;
                case 2:
                     // Câu 11:
                    if (SoThanTai(n) == true){
                       System.out.println("Đây là số thần tài"); 
                    }
                    else {
                        System.out.println("Không phải số thần tài");
                    }
                    break;
                case 3:
                    // Câu 13:
                    if (KTLechTrai(n) == true){
                        System.out.println("Đây là số lệch trái"); 
                    }
                    else {
                        System.out.println("Không phải số lệch trái");
                    }
                    break;
                case 4:
                    //Câu 15:
                    LoaiTrung(n);
                    break;
                case 5:
                    //Câu 17:
                    System.out.println("Chức năng chưa hoàn thành");break;
                case 0 :
                        System.out.println("Ban vừa bấm thoát chương trình");
                    break;
            }
        }     
    }     
}
