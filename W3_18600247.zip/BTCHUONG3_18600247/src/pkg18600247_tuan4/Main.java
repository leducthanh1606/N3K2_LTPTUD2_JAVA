/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg18600247_tuan4;

import java.util.List;

/**
 *
 * @author Dell 7450
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        NhanVien nv = new NhanVien();
        
        //tìm theo tên
        /*List<NhanVien> kq = nv.TimKiemTen("thanh");
        for (NhanVien nhanvien : kq){
            System.err.printf("%s \t %s \n",nhanvien.getMaNV(), nhanvien.getHoten());
        }*/
        
        //tim theo phòng
        /*List<NhanVien> kq = nv.TimTheoPhong("01");
        for (NhanVien nhanvien : kq){
            System.err.printf("%s \t %s \t %s \n",nhanvien.getMaNV(), nhanvien.getHoten(),nhanvien.getPhong());
        }*/
        
        //tim theo lương
        /*List<NhanVien> kq = nv.TimTheoLuong("200");
        for (NhanVien nhanvien : kq){
            System.err.printf("%s \t %s \t %s \n",nhanvien.getMaNV(), nhanvien.getHoten(),nhanvien.getLuong());
        }*/
        
        //Sửa Nhân Viên:
        //nv.SuaNhanVien("18600005");
        
        //xóa NhanVien:
        nv.XoaNhanVien("18600005");
    }   
}
