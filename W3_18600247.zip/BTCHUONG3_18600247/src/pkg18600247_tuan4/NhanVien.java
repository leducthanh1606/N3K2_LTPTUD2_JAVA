/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg18600247_tuan4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Dell 7450
 */
public class NhanVien {

    private String Hoten;
    private String MaNV;
    private String Phong;
    private String DiaChi;
    private String NgaySinh;
    private String Phai;
    private String NG_QL;
    private String Luong;
    

    public String getDiaChi() {
        return DiaChi;
    }
    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }
    public String getNgaySinh() {
        return NgaySinh;
    }
    public void setNgaySinh(String NgaySinh) {
        this.NgaySinh = NgaySinh;
    }
    public String getPhai() {
        return Phai;
    }
    public void setPhai(String Phai) {
        this.Phai = Phai;
    }
    public String getNG_QL() {
        return NG_QL;
    }
    public void setNG_QL(String NG_QL) {
        this.NG_QL = NG_QL;
    }
    public String getLuong() {
        return Luong;
    }
    public void setLuong(String Luong) {
        this.Luong = Luong;
    }
    public String getPhong() {
        return Phong;
    }
    public void setPhong(String Phong) {
        this.Phong = Phong;
    }
    public String getHoten() {
        return Hoten;
    }
    public void setHoten(String Hoten) {
        this.Hoten = Hoten;
    }
    public String getMaNV() {
        return MaNV;
    }
    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public List<NhanVien> TimKiemTen(String tukhoa) {
        List<NhanVien> ketqua = new ArrayList<>();
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlysinhvien", "root", "");
            String sql = "";
            PreparedStatement statement = null;
            if (tukhoa.isEmpty()) {
                sql = "SELECT * FROM nhanvien";
                statement = con.prepareCall(sql);
            } else {
                sql = "SELECT * FROM nhanvien where tennv like ?";
                statement = con.prepareCall(sql);
                statement.setString(1, "%" + tukhoa + "%");
            }
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getString("MANV"));
                nv.setHoten(rs.getNString("TENNV"));
                ketqua.add(nv);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(NhanVien.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return ketqua;
    }

    public List<NhanVien> TimTheoPhong(String maphong) {
        List<NhanVien> ketqua = new ArrayList<>();
        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlysinhvien", "root", "");
            String sql = "";
            PreparedStatement statement = null;
            if (maphong.isEmpty()) {
                System.out.println("Vui lòng nhập mã phòng");
                return ketqua;
            } else {
                sql = "SELECT * FROM nhanvien where phg like?";
                statement = con.prepareCall(sql);
                statement.setString(1, "%" + maphong + "%");
            }
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getString("MANV"));
                nv.setHoten(rs.getNString("TENNV"));
                nv.setPhong(rs.getString("PHG"));
                ketqua.add(nv);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(NhanVien.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return ketqua;
    }

    public List<NhanVien> TimTheoLuong(String soluong) {
        List<NhanVien> ketqua = new ArrayList<>();
        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlysinhvien", "root", "");
            String sql = "";
            PreparedStatement statement = null;
            if (soluong.isEmpty()) {
                System.out.println("Vui lòng nhập lương");
                return ketqua;
            } else {
                sql = "SELECT * FROM nhanvien where LUONG = '" + soluong + "'";
                statement = con.prepareCall(sql);
            }
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getString("MANV"));
                nv.setHoten(rs.getNString("TENNV"));
                nv.setLuong(rs.getString("LUONG"));
                ketqua.add(nv);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(NhanVien.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return ketqua;
    }

    public void SuaNhanVien(String MaNV) {
        NhanVien nv = new NhanVien();
        Connection con = null;
        try {

            //ket noi csdl
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlysinhvien", "root", "");
            String sql = "";
            Statement statement = con.createStatement();

            if (MaNV.isEmpty()) {
                System.out.println("Vui lòng nhập mã nhân viên cần sửa!!!");
                
            } else {
            Scanner sc = new Scanner(System.in);
            System.out.println("Nhap thong tin can doi:");
            System.out.print("Nhap ten: ");
            String ten = sc.nextLine();
            System.out.print("Nhap ngay sinh: ");
            String ns = sc.nextLine();
            System.out.print("Nhap phai: ");
            String phai = sc.nextLine();
            System.out.print("Nhap luong: ");
            String luong = sc.nextLine();
            System.out.print("Nhap ma dia chi: ");
            String dc = sc.nextLine();
            System.out.print("Nhap ma phong: ");
            String phong = sc.nextLine();
            System.out.print("Nhap ma nguoi quan ly: ");
            String nql = sc.nextLine();
            
                sql = String.format("update nhanvien set tennv ='%s' ,ngsinh = '%s', dchi ='%s', phai = '%s', luong = '%s', ma_nql = '%s', phg ='%s'"
                        + "Where manv = '" + MaNV + "'", ten, ns, dc, phai, luong, nql, phong);
                //statement = con.prepareCall(sql);
                int n = statement.executeUpdate(sql);
            if(n==1){
                System.out.println("UpDate thành công!!!");
            }else{
                System.out.println("UpDate thất bại!!!");
            }
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(NhanVien.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void XoaNhanVien(String MaNV) {
        NhanVien nv = new NhanVien();
        Connection con = null;
        try {

            //ket noi csdl
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlysinhvien", "root", "");
            String sql = "";
            Statement statement = con.createStatement();

            if (MaNV.isEmpty()) {
                System.out.println("Vui lòng nhập mã nhân viên cần xóa!!!");
                
            } else {
            
                sql = String.format("delete from nhanvien Where manv = '" + MaNV + "'");
                //statement = con.prepareCall(sql);
                int n = statement.executeUpdate(sql);
            if(n==1){
                System.out.println("Xóa thành công!!!");
            }else{
                System.out.println("Xóa thất bại!!!");
            }
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(NhanVien.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
